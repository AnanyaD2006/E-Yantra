
// Task 2C - MazeSolver Bot

module t2c_maze_explorer (
    input clk,
    input rst_n,
    input left, mid, right, // 0 - no wall, 1 - wall
    output reg [2:0] move
);

/*

| cmd | move  | meaning   |
|-----|-------|-----------|
| 000 | 0     | STOP      |
| 001 | 1     | FORWARD   |
| 010 | 2     | LEFT      |
| 011 | 3     | RIGHT     | 
| 100 | 4     | U_TURN    |

START POS   : 4,0
EXIT POS    : 4,8
DEADENDS    : 9

*/
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////
// Move codes
localparam STOP   = 3'b000;
localparam FWD    = 3'b001;
localparam LEFT_M = 3'b010;
localparam RIGHT_M= 3'b011;
localparam UTURN  = 3'b100;

localparam START_X = 4;
localparam START_Y = 8;
localparam EXIT_X  = 4;
localparam EXIT_Y  = 0;

// Facing directions/ Position and facing: facing: 0=N,1=E,2=S,3=W
localparam NORTH = 2'd0;
localparam EAST  = 2'd1;
localparam SOUTH = 2'd2;
localparam WEST  = 2'd3;

// States
localparam COUNT = 2'd0;
localparam MOVE = 2'd1; // Sample sensors
localparam READ = 2'd2;


reg done;



integer i, j;
reg [3:0] cur_x;
reg [3:0] cur_y;
reg [1:0] facing;
reg [1:0] counter;


reg [2:0] candidate_move;
reg[3:0] dead; 

reg left_s, mid_s, right_s;
reg [1:0] state; 
reg [1:0] left_visits, fwd_visits, right_visits;
reg [3:0] lx, ly, fx, fy, rx, ry;

// function output / temporary pose
reg [11:0] next_pose;
function [11:0] compute_next_pose;
    input [3:0] cx;          // current x (0..8)
    input [3:0] cy;          // current y (0..8)
    input [1:0] cf;          // current facing 0=N,1=E,2=S,3=W
    input [2:0] mv;          // move command: use same encodings (FWD, LEFT_M, RIGHT_M, UTURN)
    reg [3:0] nx;
    reg [3:0] ny;
    reg [1:0] nf;
    begin
        // default: no change
        nx = cx;
        ny = cy;
        nf = cf;

        case (cf)
            // ---------------- Facing North ----------------
            2'd0: begin
                case (mv)
                    3'b001: if (cy != 4'd0) ny = cy - 1;           // FWD
                    3'b010: if (cx != 4'd0) begin nx = cx - 1; nf = 2'd3; end // LEFT
                    3'b011: if (cx != 4'd8) begin nx = cx + 1; nf = 2'd1; end // RIGHT
                    3'b100: begin  // UTURN — face south + step one down if possible
                        nf = 2'd2;
                        if (cy != 4'd8) ny = cy + 1;
                    end
                endcase
            end

            // ---------------- Facing East ----------------
            2'd1: begin
                case (mv)
                    3'b001: if (cx != 4'd8) nx = cx + 1;           // FWD
                    3'b010: if (cy != 4'd0) begin ny = cy - 1; nf = 2'd0; end // LEFT
                    3'b011: if (cy != 4'd8) begin ny = cy + 1; nf = 2'd2; end // RIGHT
                    3'b100: begin  // UTURN — face west + step one left if possible
                        nf = 2'd3;
                        if (cx != 4'd0) nx = cx - 1;
                    end
                endcase
            end

            // ---------------- Facing South ----------------
            2'd2: begin
                case (mv)
                    3'b001: if (cy != 4'd8) ny = cy + 1;           // FWD
                    3'b010: if (cx != 4'd8) begin nx = cx + 1; nf = 2'd1; end // LEFT
                    3'b011: if (cx != 4'd0) begin nx = cx - 1; nf = 2'd3; end // RIGHT
                    3'b100: begin  // UTURN — face north + step one up if possible
                        nf = 2'd0;
                        if (cy != 4'd0) ny = cy - 1;
                    end
                endcase
            end

            // ---------------- Facing West ----------------
            2'd3: begin
                case (mv)
                    3'b001: if (cx != 4'd0) nx = cx - 1;           // FWD
                    3'b010: if (cy != 4'd8) begin ny = cy + 1; nf = 2'd2; end // LEFT
                    3'b011: if (cy != 4'd0) begin ny = cy - 1; nf = 2'd0; end // RIGHT
                    3'b100: begin  // UTURN — face east + step one right if possible
                        nf = 2'd1;
                        if (cx != 4'd8) nx = cx + 1;
                    end
                endcase
            end
        endcase

        // pack result: [11:8]=nx, [7:4]=ny, [3:2]=nf
        compute_next_pose = {nx, ny, nf, 2'b00};
    end
endfunction
reg key;
 


initial begin
move<=STOP;

end

always @(posedge clk) begin
if (!rst_n) begin
    state <= COUNT;
    move  <= STOP;
	 key<=0;
    
    dead<=0;
	 left_s=0;
	 right_s=0;
	 mid_s=0;
	 left_visits  <=  0;
    fwd_visits   <=  0;
    right_visits <=  0;
    cur_x <= START_X;
    cur_y <= START_Y;
    facing <= NORTH;
	 done<=1;
	 counter<=2;
	

    
    
   


    end
	 else begin
        case (state)
		      COUNT: begin
				if(counter>0) begin
				counter<=counter-1;
				state<=COUNT;
				end
				else begin
				state<=MOVE;
				end
				
				end
            MOVE: begin
				
				
			
				if(cur_x==4 && cur_y==0 && facing==NORTH && dead<6) begin
					  left_s  = left;
                 mid_s   = 1;
                 right_s = right;
					  
end
					  
					   
					  else if(cur_x==4 && cur_y==0 &&  facing==WEST &&dead<6) begin
					  left_s  = left;
                 mid_s   = mid;
                 right_s = 1;
					  
					  
					  
					  end 
					  else if(cur_x==4 && cur_y==0 && facing==EAST && dead<6) begin
					  left_s  = 1;
                 mid_s   = mid;
                 right_s = right;
					
					  
end
					  
					  
					else if(cur_x==4 && cur_y==8 && facing == SOUTH)begin
					 left_s  = left;
                mid_s   = 1;
                right_s = right;
					
					
					
					 
					end
					else if(cur_x==4 && cur_y==8 && facing == WEST )begin
					 left_s  = 1;
               mid_s   = mid;
                right_s = right;
					
					 
					end
					else if(cur_x==4 && cur_y==8 && facing == EAST)begin
					left_s  = left;
               mid_s   = mid;
                right_s = 1;
					
					 
					end
					 else begin  // Sample sensor inputs
                left_s  = left;
                mid_s   = mid;
                right_s = right;
					 end
					 
					 
				 
                 
					 
					
					  
     if ((cur_x==1 && cur_y==5) || (cur_x==1 && cur_y==4) || (cur_x==3 && cur_y==6) ||(cur_x==8 && cur_y==1)) begin
	  
			$display("[out] -> %0d,%0d",cur_x,cur_y);
	  
     if (left_s == 1'b0 ) begin
        candidate_move = LEFT_M;
        
    end 
    else if (mid_s == 1'b0 )begin
        candidate_move = FWD;
						
    end 				
    
	 else if (right_s == 1'b0 ) begin
        candidate_move = RIGHT_M;
        
    end 
	  
	 
    else begin
        candidate_move =  UTURN ;
		  dead=dead +1;
        
    end
	  
	  end
	  
			//$display("[out] -> lv,rv=(%0d,%0d) Fv=%0d",left_visits, right_visits,fwd_visits);
    else begin

     if (right_s == 1'b0 ) begin
        candidate_move = RIGHT_M;
        
    end 
    else if (mid_s == 1'b0 )begin
        candidate_move = FWD;
						
    end 				
    
	 else if (left_s == 1'b0 ) begin
        candidate_move = LEFT_M;
        
    end 
	  
	 
    else begin
        candidate_move =  UTURN ;
		  dead=dead +1;
        
    end
	 end
	 move   <= candidate_move;
    // compute and commit next pose
	 next_pose = compute_next_pose(cur_x, cur_y, facing, candidate_move);
						cur_x  <= next_pose[11:8];
                 cur_y  <= next_pose[7:4];
                 facing <= next_pose[3:2];
					  

	 
    

					 
					 
					 
					
					 
					 
					
				state<=READ;
				end

 READ: begin
 

					 state<=MOVE;
 
 
end 





        endcase
    end
end


/*
Add your logic here
*/


//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////

endmodule






