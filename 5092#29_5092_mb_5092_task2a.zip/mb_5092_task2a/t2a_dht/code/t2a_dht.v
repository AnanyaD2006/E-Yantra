module t2a_dht(
    input clk_50M,
    input reset,
    inout sensor,
    output reg [7:0] T_integral,
    output reg [7:0] RH_integral,
    output reg [7:0] T_decimal,
    output reg [7:0] RH_decimal,
    output reg [7:0] Checksum,
    output reg data_valid
);

    initial begin
        T_integral = 0;
        RH_integral = 0;
        T_decimal = 0;
        RH_decimal = 0;
        Checksum = 0;
        data_valid = 0;
    end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////

    // Parameters for timing based on the 50MHz clock
    localparam T_1S_DELAY      = 50_000_000; // 1-second delay between readings
    localparam T_18MS_LOW      = 900_000;    // 18ms start pulse (low)
    localparam T_40US_HIGH     = 2_000;      // 40us start pulse (high)
    localparam T_80US_RESPONSE = 4_000;      // 80us response pulse
    localparam T_50US_DATA_LOW = 2_500;      // 50us data bit start (low)
    localparam T_70US_DATA_ONE = 3_500;      // 70us data bit '1' (high)
    // Threshold to differentiate a logic '0' from a logic '1'
    // This is set between the 26us ('0') and 70us ('1') high pulses. ~48us.
    localparam T_BIT_THRESHOLD = 2_400;

    // FSM States - Reduced from 11 to 9 states
    localparam [3:0] S_START_LOW        = 4'd0,
                      S_START_HIGH       = 4'd1,
                      S_WAIT_RESPONSE    = 4'd2,
                      S_RESPONSE_LOW     = 4'd3,
                      S_RESPONSE_HIGH    = 4'd4,
                      S_DATA_START_LOW   = 4'd5,
                      S_DATA_READ_HIGH   = 4'd6,
                      S_VALIDATE         = 4'd7,
                      S_DATA_VALID_PULSE = 4'd8;

    // Internal state and data registers
    reg [3:0]  state         = S_START_LOW;
    reg [25:0] timer         = 0; // Timer needs to count up to 50,000,000
    reg [5:0]  bit_count     = 0; // Counter for the 40 data bits
    reg [39:0] data_buffer   = 0; // Buffer to store incoming data bits
    
    // Bidirectional pin control logic
    reg sensor_out = 1'b1;
    reg sensor_en  = 1'b0; // 0 for input (high-Z), 1 for output
    assign sensor = sensor_en ? sensor_out : 1'bz;
    
    wire [7:0] calculated_checksum;
    assign calculated_checksum = data_buffer[39:32] + data_buffer[31:24] + data_buffer[23:16] + data_buffer[15:8];

    // Main FSM logic
    always @(posedge clk_50M or posedge reset) begin
        
        if(reset) begin // This is the main FSM execution block
            
            case (state)
                // Send the start signal: pull low for 18ms
                S_START_LOW: begin
                    sensor_en <= 1;
                    sensor_out <= 0;
                    if (timer < T_18MS_LOW) begin
                        timer <= timer + 26'd1;
                    end else begin
                        timer <= 0;
                        state <= S_START_HIGH;
                    end
                end

                // Complete the start signal: pull high for 40us
                S_START_HIGH: begin
                    sensor_out <= 1;
                    if (timer < T_40US_HIGH) begin
                        timer <= timer + 26'd1;
                    end else begin
                        timer <= 0;
                        sensor_en <= 0; // Release the bus for the sensor
                        bit_count <= 0;
                        data_buffer <= 0;
                        state <= S_WAIT_RESPONSE;
                    end
                end

                // Wait for the DHT11 to start its response
                S_WAIT_RESPONSE: begin
                    if (sensor == 0) begin // Sensor pulled low
                        timer <= 0;
                        state <= S_RESPONSE_LOW;
                    end else if (timer > T_80US_RESPONSE + 1000) begin // Timeout
                        state <= S_START_LOW; // Restart
                        timer <= 0; // Reset timer on failure
                    end else begin
                        timer <= timer + 26'd1;
                    end
                end

                // Check the 80us low part of the response
                S_RESPONSE_LOW: begin
                    if (sensor == 1) begin // Sensor released low
                        timer <= 0;
                        state <= S_RESPONSE_HIGH;
                    end else if (timer > T_80US_RESPONSE + 1000) begin // Timeout
                        state <= S_START_LOW; // Restart
                        timer <= 0; // Reset timer on failure
                    end else begin
                        timer <= timer + 26'd1;
                    end
                end

                // Check the 80us high part of the response
                S_RESPONSE_HIGH: begin
                    if (sensor == 0) begin // Sensor pulled low (start of data)
                        timer <= 0;
                        state <= S_DATA_START_LOW;
                    end else if (timer > T_80US_RESPONSE + 1000) begin // Timeout
                        state <= S_START_LOW; // Restart
                        timer <= 0; // Reset timer on failure
                    end else begin
                        timer <= timer + 26'd1;
                    end
                end

                // Wait through the 50us low pulse at the start of each data bit
                S_DATA_START_LOW: begin
                    if (sensor == 1) begin
                        timer <= 0;
                        state <= S_DATA_READ_HIGH;
                    end else if (timer > T_50US_DATA_LOW + 1000) begin // Timeout
                        state <= S_START_LOW; // Restart
                        timer <= 0; // Reset timer on failure
                    end else begin
                        timer <= timer + 26'd1;
                    end
                end

                S_DATA_READ_HIGH: begin
                    // Check if the pulse has ended (sensor pulls low OR goes high-Z)
                    if (sensor == 0 || sensor === 1'bz) begin
                        // Record the bit, calculated correctly regardless of how the pulse ended
                        data_buffer <= {data_buffer[38:0], (timer > T_BIT_THRESHOLD)};
                        
                        if (bit_count == 39) begin
                            // This was the last bit, start 2 clock cycle delay before validation
                            timer <= 0;
                            state <= S_VALIDATE;
                        end else begin
                            // Not the last bit, move to the next one
                            bit_count <= bit_count + 6'd1;
                            timer <= 0;
                            state <= S_DATA_START_LOW;
                        end
                        
                    // Check for a timeout (sensor stuck high)
                    end else if (timer > T_70US_DATA_ONE + 1000) begin 
                        state <= S_START_LOW; // Restart
                        timer <= 0; // Reset timer on failure
                        
                    // Otherwise, pulse is still high, keep counting
                    end else begin
                        timer <= timer + 26'd1;
                    end
                end

                // Validate the received data using the checksum (with 2 clock cycle delay)
                S_VALIDATE: begin
                    if (timer < 2) begin
                        // Wait for 2 clock cycles
                        timer <= timer + 26'd1;
                    end else if (timer < 3) begin
                        // Checksum calculation (low 8 bits of the sum)
                        if (data_buffer[7:0] == calculated_checksum) begin
                            RH_integral <= data_buffer[39:32];
                            RH_decimal  <= data_buffer[31:24];
                            T_integral  <= data_buffer[23:16];
                            T_decimal   <= data_buffer[15:8];
                            Checksum    <= data_buffer[7:0];
                            data_valid  <= 1'b1;
									 timer <= timer + 26'd1;
                        end else begin // Checksum failed
                            data_valid <= 1'b0;
                            state <= S_START_LOW;
                        end	
					    end else begin
								data_valid <= 1'b0;
								timer <= 0;
							   state <= S_START_LOW;
                   end
					 end
               // Assert data_valid for a single clock cycle
                S_DATA_VALID_PULSE: begin
                    data_valid <= 1'b0;
                    timer <= 0;
                    state <= S_START_LOW; // Go back to start for the next reading
                end

                default: begin
                    state <= S_START_LOW;
                end
            endcase
        end
        else begin 
            state <= S_START_LOW;
            timer <= 0;
            bit_count <= 0;
            data_buffer <= 0;
            sensor_en <= 0;
            sensor_out <= 1'b1;
            data_valid <= 1'b0;
            T_integral <= 0;
            T_decimal <= 0;
            RH_integral <= 0;
            RH_decimal <= 0;
            Checksum <= 0;
            
        end
    end
//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////
    
endmodule